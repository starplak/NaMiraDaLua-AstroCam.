package br.com.namiradalua.astrocam

import android.app.Activity
import android.hardware.usb.UsbManager
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface

/**
 * Tela inicial do AstroCam.
 * Esta primeira etapa identifica dispositivos USB conectados.
 * O preview UVC será integrado na próxima etapa usando uma engine UVC validada.
 */
class MainActivity : Activity() {
    private val bg = Color.rgb(8, 15, 26)
    private val panel = Color.rgb(19, 34, 53)
    private val blue = Color.rgb(57, 167, 255)
    private val white = Color.rgb(235, 243, 252)
    private val muted = Color.rgb(151, 173, 198)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildScreen()
    }

    override fun onResume() {
        super.onResume()
        // A atualização da lista USB será refletida ao recriar a tela nesta versão inicial.
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 22)
            setBackgroundColor(bg)
        }

        root.addView(text("NA MIRA DA LUA", 14f, blue, true))
        root.addView(text("ASTROCAM", 30f, white, true))
        root.addView(text("CENTRAL DE CAPTURA ASTRONÔMICA • V0.1.0", 11f, muted, false))

        val preview = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(16, 34, 16, 34)
            setBackgroundColor(Color.rgb(3, 8, 15))
        }
        preview.addView(text("PRÉ-VISUALIZAÇÃO", 17f, white, true))
        preview.addView(text("A integração da câmera SVBONY SV105 será ativada na próxima etapa.", 12f, muted, false))
        val p = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ).apply { topMargin = 22; bottomMargin = 18 }
        root.addView(preview, p)

        val usbManager = getSystemService(USB_SERVICE) as UsbManager
        val devices = usbManager.deviceList.values
        val usbStatus = if (devices.isEmpty()) {
            "Nenhuma câmera USB detectada neste momento."
        } else {
            devices.joinToString(separator = "\n") {
                "USB: ${it.deviceName} • VID ${it.vendorId} • PID ${it.productId}"
            }
        }
        root.addView(card("CONEXÃO USB", usbStatus))
        root.addView(card("CONTROLES PLANEJADOS", "Exposição • Ganho • Brilho • Contraste • Gamma • Saturação • Nitidez"))
        root.addView(card("CAPTURA", "Fotografia • Vídeo • Histograma • Tela cheia para projetor"))
        root.addView(text("Nota: os controles físicos disponíveis dependem dos recursos UVC anunciados pela câmera. Os filtros digitais serão processados pelo aplicativo.", 11f, muted, false))
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun card(title: String, body: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(panel)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 12 }
            layoutParams = params
            addView(text(title, 13f, blue, true))
            addView(text(body, 13f, white, false))
        }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 4, 0, 4)
        }
}
