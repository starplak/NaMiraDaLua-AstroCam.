# Na Mira da Lua AstroCam — projeto inicial

Projeto Android nativo em Kotlin para desenvolver um aplicativo de captura astronômica com a câmera SVBONY SV105 no Realme C13.

## Estado atual

Este pacote é o esqueleto inicial do aplicativo, não uma versão final. Inclui identidade visual, tela inicial e identificação básica de dispositivos USB. A visualização UVC real da SV105 e os controles da câmera ainda precisam ser integrados e testados no aparelho.

## Compilar APK pelo GitHub

1. Crie um repositório no GitHub chamado `NaMiraDaLua-AstroCam`.
2. Envie para a branch `main` todos os arquivos e pastas deste projeto (não envie apenas o ZIP).
3. Abra a aba **Actions** do repositório.
4. Se solicitado, habilite GitHub Actions.
5. Abra **Build Na Mira da Lua AstroCam APK** e clique em **Run workflow**. Um envio para `main` também inicia a compilação automaticamente.
6. Quando terminar com sucesso, abra a execução e baixe o artefato `NaMiraDaLua-AstroCam-debug` na seção **Artifacts**. Dentro dele estará `app-debug.apk`.

O workflow usa JDK 17, Android SDK e Gradle 8.9. Em repositório público, os executores padrão do GitHub Actions têm franquia gratuita conforme os limites vigentes do GitHub. Repositórios privados consomem a franquia mensal da conta.

## Plano técnico

1. Confirmar identificação UVC e formatos/resoluções anunciados pela SV105.
2. Integrar uma engine UVC Android mantida e fixar uma versão compatível após validar a API.
3. Ler apenas os controles UVC realmente suportados pela câmera (por exemplo, exposição e ganho).
4. Adicionar processamento digital: brilho, contraste, gamma, saturação, nitidez e redução de ruído.
5. Implementar captura de fotos/vídeos, histograma e modo de projeção em tela cheia.

## Requisitos para desenvolvimento local

Android Studio, JDK 17 e Android SDK 35. O primeiro build verifica a estrutura do app; ainda não produz a experiência completa da câmera.

## Observação

A biblioteca UVC deve ser integrada com uma versão/tag fixada após validar a API e compatibilidade. Não use `latest` em produção. O projeto não altera firmware nem promete controles físicos que a câmera não exponha.
